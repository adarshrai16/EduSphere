import { Webhook } from 'svix'

import User from '../models/User.js'
import Stripe from 'stripe'
import Purchase from '../models/Purchase.js'
import Course from '../models/courseModel.js'


// =====================================================
// CLERK WEBHOOK
// =====================================================

export const clerkWebhooks = async (
    req,
    res
) => {

    try {

        const whook = new Webhook(process.env.CLERK_WEBHOOK_SECRET)


        await whook.verify(JSON.stringify(req.body),
            {
                'svix-id':
                    req.headers['svix-id'],

                'svix-timestamp':
                    req.headers['svix-timestamp'],

                'svix-signature':
                    req.headers['svix-signature']
            }
        )


        const {data,type} = req.body


        switch (type) {

            case 'user.created': {

                const email =data.email_addresses?.[0]?.email_address || ''


                const userData = {
                    _id:data.id,
                    email,
                    name:
                        `${data.first_name || ''} ${
                            data.last_name || ''
                        }`.trim() ||
                        'User',
                    imageUrl:
                        data.image_url || ''
                }


                await User.create(
                    userData
                )


                return res.json({
                    success: true
                })
            }


            case 'user.updated': {

                const email =
                    data.email_addresses?.[0]
                        ?.email_address || ''


                const userData = {

                    email,

                    name:
                        `${data.first_name || ''} ${
                            data.last_name || ''
                        }`.trim() ||
                        'User',

                    imageUrl:data.image_url || ''
                }

                await User.findByIdAndUpdate(data.id,userData,{new: true})
                return res.json({success: true})
            }

            case 'user.deleted': {
                await User.findByIdAndDelete(data.id)
                return res.json({success: true})
            }
            default:
                return res.json({success: true})
        }

    } catch (error) {
        console.error('Clerk webhook error:',error)

        return res.status(400).json({success: false, message: error.message})
    }
}
// =====================================================
// STRIPE
// =====================================================

const stripeInstance =new Stripe(process.env.STRIPE_SECRET_KEY)
export const stripeWebhooks =async (req,res) => {
        const signature = req.headers['stripe-signature' ]

        let event
        try {
            event =Stripe.webhooks.constructEvent( req.body,signature,process.env.STRIPE_WEBHOOK_SECRET  )
        } catch (error) {
            console.error('Stripe webhook error:',error)
            return res.status(400).send(`Webhook Error: ${error.message}`)
        }


        try {

            switch (event.type) {

                // =====================================
                // PAYMENT SUCCESS
                // =====================================

                case 'payment_intent.succeeded': {
                    const paymentIntent =event.data.object
                    const paymentIntentId =paymentIntent.id
                    const session =await stripeInstance.checkout.sessions.list({ payment_intent:paymentIntentId })
                    const checkoutSession =session.data?.[0]
                    if (!checkoutSession) {
                        console.error('Stripe checkout session not found' )
                        break
                    }

                    const {purchaseId} = checkoutSession.metadata || {}
                    if (!purchaseId) {
                        console.error('Purchase ID missing from Stripe metadata')
                        break
                    }

                    const purchaseData = await Purchase.findById(purchaseId )
                    if (!purchaseData) {
                        console.error('Purchase not found')
                        break
                    }

                    const userData =await User.findById(purchaseData.userId )
                    const courseData = await Course.findById( purchaseData.courseId )
                    if (!userData || !courseData ) {
                        console.error('User or course not found' )
                        break
                    }

                    // Add student only once

                    const alreadyEnrolled =courseData.enrolledStudents.some(id =>id.toString() ===userData._id.toString())
                    if (!alreadyEnrolled) {
                        courseData.enrolledStudents.push(userData._id)
                        await courseData.save()
                    }

                    // Add course only once

                    const alreadyInUserCourses =userData.enrolledCourses.some(id =>id.toString() ===courseData._id.toString() )
                    if (!alreadyInUserCourses ) {
                        userData.enrolledCourses.push( courseData._id )
                        await userData.save()
                    }
                    purchaseData.status ='completed'
                    await purchaseData.save()
                    break
                }
                // =====================================
                // PAYMENT FAILED
                // =====================================
                case 'payment_intent.payment_failed': {
                    const paymentIntent = event.data.object
                    const paymentIntentId = paymentIntent.id
                    const session =await stripeInstance.checkout.sessions.list({ payment_intent:  paymentIntentId })
                    
                    const checkoutSession = session.data?.[0]
                    if (!checkoutSession) {break}

                    const { purchaseId } =checkoutSession.metadata || {}
                    if (!purchaseId) {break}

                    const purchaseData =
                        await Purchase.findById( purchaseId)
                    if (purchaseData) {
                        purchaseData.status = 'failed'
                        await purchaseData.save()
                    }
                    break
                }
                default:
                     console.log(  `Unhandled event type ${event.type}`  )
            }
            res.json({  received: true })
        } catch (error) {
            console.error( 'Stripe webhook processing error:', error   )
            res.status(500).json({  success: false, message: error.message })
        }
    }