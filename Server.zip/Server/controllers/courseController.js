import Course from '../models/courseModel.js'


// =====================================================
// GET ALL COURSES
// =====================================================

export const getAllCourses = async (
    req,
    res
) => {

    try {

        const courses =
            await Course.find({
                isPublished: true
            })
            .select(
                '-courseContent -enrolledStudents'
            )
            .populate({
                path: 'educator',
                select: 'name imageUrl email'
            })


        res.json({
            success: true,
            courses
        })

    } catch (error) {

        console.error(
            'Get all courses error:',
            error
        )

        res.json({
            success: false,
            message: error.message
        })
    }
}


// =====================================================
// GET COURSE BY ID
// =====================================================

export const getCourseId = async (
    req,
    res
) => {

    const {
        id
    } = req.params


    try {

        const courseData =
            await Course.findById(id)
                .populate({
                    path: 'educator',
                    select: 'name imageUrl email'
                })


        if (!courseData) {
            return res.json({
                success: false,
                message: 'Course not found'
            })
        }


        // Hide non-preview lecture URLs

        courseData.courseContent?.forEach(
            chapter => {

                chapter.chapterContent?.forEach(
                    lecture => {

                        if (
                            !lecture.isPreviewFree
                        ) {
                            lecture.lectureUrl = ''
                        }

                    }
                )

            }
        )


        res.json({
            success: true,
            courseData
        })

    } catch (error) {

        console.error(
            'Get course error:',
            error
        )

        res.json({
            success: false,
            message: error.message
        })
    }
}