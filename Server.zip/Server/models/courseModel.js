import mongoose from 'mongoose'


// =====================================================
// LECTURE SCHEMA
// =====================================================

const lectureSchema =
    new mongoose.Schema(
        {
            lectureId: {
                type: String,
                required: true
            },

            lectureTitle: {
                type: String,
                required: true
            },

            lectureDuration: {
                type: Number,
                required: true
            },

            lectureUrl: {
                type: String,
                required: true
            },

            isPreviewFree: {
                type: Boolean,
                default: false
            },

            lectureOrder: {
                type: Number,
                required: true
            }
        },
        {
            _id: false
        }
    )


// =====================================================
// CHAPTER SCHEMA
// =====================================================

const chapterSchema =
    new mongoose.Schema(
        {
            chapterId: {
                type: String,
                required: true
            },

            chapterOrder: {
                type: Number,
                required: true
            },

            chapterTitle: {
                type: String,
                required: true
            },

            chapterContent: [
                lectureSchema
            ]
        },
        {
            _id: false
        }
    )


// =====================================================
// COURSE SCHEMA
// =====================================================

const courseSchema =
    new mongoose.Schema(
        {
            courseTitle: {
                type: String,
                required: true
            },

            courseDescription: {
                type: String,
                required: true
            },

            courseThumbnail: {
                type: String,
                default: ''
            },

            coursePrice: {
                type: Number,
                required: true
            },

            isPublished: {
                type: Boolean,
                default: false
            },

            discount: {
                type: Number,
                required: true,
                min: 0,
                max: 100
            },

            courseContent: {
                type: [chapterSchema],
                default: []
            },

            courseRatings: [
                {
                    userId: {
                        type: String
                    },

                    rating: {
                        type: Number,
                        min: 1,
                        max: 5
                    }
                }
            ],

            educator: {
                type: String,
                ref: 'User',
                required: true
            },

            enrolledStudents: [
                {
                    type: String,
                    ref: 'User'
                }
            ]
        },

        {
            timestamps: true,
            minimize: false
        }
    )


const Course =
    mongoose.model(
        'Course',
        courseSchema
    )


export default Course