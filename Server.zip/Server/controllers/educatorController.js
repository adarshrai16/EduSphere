import { clerkClient } from '@clerk/express'
import { v2 as cloudinary } from 'cloudinary'

import Course from '../models/courseModel.js'
import Purchase from '../models/Purchase.js'
import User from '../models/User.js'


// =====================================================
// UPDATE ROLE TO EDUCATOR
// =====================================================

export const updateRoleToEducator = async (req, res) => {
    try {

        const userId = req.auth?.userId

        if (!userId) {
            return res.json({
                success: false,
                message: 'User is not authenticated'
            })
        }

        await clerkClient.users.updateUserMetadata(
            userId,
            {
                publicMetadata: {
                    role: 'educator'
                }
            }
        )

        res.json({
            success: true,
            message: 'You can publish a course now'
        })

    } catch (error) {

        console.error(
            'Update educator role error:',
            error
        )

        res.json({
            success: false,
            message: error.message
        })
    }
}


// =====================================================
// ADD NEW COURSE
// =====================================================

export const addNewCourse = async (req, res) => {

    try {

        const {
            courseData
        } = req.body

        const imageFile =
            req.file

        const educatorId =
            req.auth?.userId


        if (!educatorId) {
            return res.json({
                success: false,
                message: 'User is not authenticated'
            })
        }


        if (!imageFile) {
            return res.json({
                success: false,
                message: 'Please upload a course image'
            })
        }


        if (!courseData) {
            return res.json({
                success: false,
                message: 'Course data is missing'
            })
        }


        const parsedCourseData =
            JSON.parse(courseData)


        parsedCourseData.educator =
            educatorId


        const imageUpload =
            await cloudinary.uploader.upload(
                imageFile.path
            )


        parsedCourseData.courseThumbnail =
            imageUpload.secure_url


        const newCourse =
            await Course.create(
                parsedCourseData
            )


        res.json({
            success: true,
            message: 'Course added successfully',
            course: newCourse
        })

    } catch (error) {

        console.error(
            'Add course error:',
            error
        )

        res.json({
            success: false,
            message: error.message
        })
    }
}


// =====================================================
// GET EDUCATOR COURSES
// =====================================================

export const getEducatorCourses = async (
    req,
    res
) => {

    try {

        const educatorId =
            req.auth?.userId


        if (!educatorId) {
            return res.json({
                success: false,
                message: 'User is not authenticated'
            })
        }


        const courses =
            await Course.find({
                educator: educatorId
            })


        res.json({
            success: true,
            courses
        })

    } catch (error) {

        console.error(
            'Get educator courses error:',
            error
        )

        res.json({
            success: false,
            message: error.message
        })
    }
}


// =====================================================
// EDUCATOR DASHBOARD DATA
// =====================================================

export const getEducatorDashboardData = async (
    req,
    res
) => {

    try {

        const educatorId =
            req.auth?.userId


        if (!educatorId) {
            return res.json({
                success: false,
                message: 'User is not authenticated'
            })
        }


        const courses =
            await Course.find({
                educator: educatorId
            })


        const totalCourses =
            courses.length


        const courseIds =
            courses.map(
                course => course._id
            )


        // ---------------------------------------------
        // TOTAL EARNINGS
        // ---------------------------------------------

        const purchases =
            await Purchase.find({
                courseId: {
                    $in: courseIds
                },
                status: 'completed'
            })


        const totalEarnings =
            purchases.reduce(
                (
                    sum,
                    purchase
                ) =>
                    sum +
                    Number(
                        purchase.amount || 0
                    ),
                0
            )


        // ---------------------------------------------
        // ENROLLED STUDENTS
        // ---------------------------------------------

        const enrolledStudentsData = []


        for (
            const course of courses
        ) {

            if (
                !course.enrolledStudents ||
                course.enrolledStudents.length === 0
            ) {
                continue
            }


            const students =
                await User.find({
                    _id: {
                        $in:
                            course.enrolledStudents
                    }
                }).select(
                    'name imageUrl email'
                )


            students.forEach(
                student => {

                    enrolledStudentsData.push({
                        courseTitle:
                            course.courseTitle,

                        student
                    })

                }
            )
        }


        res.json({
            success: true,

            dashboardData: {
                totalCourses,
                totalEarnings,
                enrolledStudentsData
            }
        })

    } catch (error) {

        console.error(
            'Educator dashboard error:',
            error
        )

        res.json({
            success: false,
            message: error.message
        })
    }
}


// =====================================================
// ENROLLED STUDENTS
// =====================================================

export const getEnrolledStudentsData = async (
    req,
    res
) => {

    try {

        const educatorId =
            req.auth?.userId


        if (!educatorId) {
            return res.json({
                success: false,
                message: 'User is not authenticated'
            })
        }


        const courses =
            await Course.find({
                educator: educatorId
            })


        const courseIds =
            courses.map(
                course => course._id
            )


        const purchases =
            await Purchase.find({
                courseId: {
                    $in: courseIds
                },
                status: 'completed'
            })
            .populate(
                'userId',
                'name email imageUrl'
            )
            .populate(
                'courseId',
                'courseTitle'
            )


        const enrolledStudents =
            purchases
                .filter(
                    purchase =>
                        purchase.userId &&
                        purchase.courseId
                )
                .map(
                    purchase => ({

                        student:
                            purchase.userId,

                        courseTitle:
                            purchase.courseId.courseTitle,

                        purchaseDate:
                            purchase.createdAt
                    })
                )


        res.json({
            success: true,
            enrolledStudents
        })

    } catch (error) {

        console.error(
            'Get enrolled students error:',
            error
        )

        res.json({
            success: false,
            message: error.message
        })
    }
}