import {
    clerkClient
} from '@clerk/express'


// =====================================================
// PROTECT EDUCATOR ROUTES
// =====================================================

export const protectEducator =async (req,res,next) => {
        try {

            const userId = req.auth?.userId


            if (!userId) {
                return res.status(401).json({success: false, message: 'User is not authenticated' })
            }


            const user =await clerkClient.users.getUser(userId)
            if (user.publicMetadata?.role !=='educator'
            ) {
                return res.status(403).json({  success: false,message:'You are not an educator'
                })
            }


            next()

        } catch (error) {

            console.error(
                'Educator authentication error:',
                error
            )

            res.status(500).json({
                success: false,
                message: error.message
            })
        }
    }