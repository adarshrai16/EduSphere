import express from 'express'

import {
    updateRoleToEducator,
    addNewCourse,
    getEducatorCourses,
    getEducatorDashboardData,
    getEnrolledStudentsData
} from '../controllers/educatorController.js'

import upload from '../configs/multer.js'

import {
    protectEducator
} from '../middlewares/authMiddleware.js'


const educatorRouter =
    express.Router()


// =====================================================
// BECOME EDUCATOR
// =====================================================

educatorRouter.put(
    '/update-role',
    updateRoleToEducator
)


// =====================================================
// ADD COURSE
// =====================================================

educatorRouter.post(
    '/add-course',
    upload.single('image'),
    protectEducator,
    addNewCourse
)


// =====================================================
// EDUCATOR COURSES
// =====================================================

educatorRouter.get(
    '/courses',
    protectEducator,
    getEducatorCourses
)


// =====================================================
// DASHBOARD
// =====================================================

educatorRouter.get(
    '/dashboard',
    protectEducator,
    getEducatorDashboardData
)


// =====================================================
// ENROLLED STUDENTS
// =====================================================

educatorRouter.get(
    '/enrolled-students',
    protectEducator,
    getEnrolledStudentsData
)


export default educatorRouter