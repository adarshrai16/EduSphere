import express from 'express'
import cors from 'cors'
import 'dotenv/config'

import connectDB from './configs/mongodb.js'
import {
    clerkWebhooks,
    stripeWebhooks
} from './controllers/webhooks.js'

import educatorRouter
    from './routes/educatorroutes.js'

import {
    clerkMiddleware
} from '@clerk/express'

import connectCloudinary
    from './configs/cloudinary.js'

import courseRouter
    from './routes/courseRoute.js'

import userRouter
    from './routes/userRoutes.js'


// =====================================================
// INITIALIZE EXPRESS
// =====================================================

const app =
    express()


// =====================================================
// DATABASE
// =====================================================

await connectDB()

await connectCloudinary()


// =====================================================
// CORS
// =====================================================

const allowedOrigins = [

    'http://localhost:5173',

    'http://127.0.0.1:5173'

]


app.use(
    cors({
        origin: function (
            origin,
            callback
        ) {

            // Allow requests without origin
            // such as Postman

            if (!origin) {
                return callback(
                    null,
                    true
                )
            }


            if (
                allowedOrigins.includes(
                    origin
                )
            ) {

                return callback(
                    null,
                    true
                )
            }


            return callback(
                new Error(
                    'Not allowed by CORS'
                )
            )
        },

        credentials: true
    })
)


// =====================================================
// CLERK MIDDLEWARE
// =====================================================

app.use(
    clerkMiddleware()
)


// =====================================================
// BASIC ROUTE
// =====================================================

app.get(
    '/',
    (req, res) => {

        res.send(
            'API Working'
        )
    }
)


// =====================================================
// CLERK WEBHOOK
// =====================================================

app.post(
    '/clerk',
    express.json(),
    clerkWebhooks
)


// =====================================================
// EDUCATOR ROUTES
// =====================================================

app.use(
    '/api/educator',
    express.json(),
    educatorRouter
)


// =====================================================
// COURSE ROUTES
// =====================================================

app.use(
    '/api/course',
    express.json(),
    courseRouter
)


// =====================================================
// USER ROUTES
// =====================================================

app.use(
    '/api/user',
    express.json(),
    userRouter
)


// =====================================================
// STRIPE WEBHOOK
// =====================================================

app.post(
    '/stripe',
    express.raw({
        type: 'application/json'
    }),
    stripeWebhooks
)


// =====================================================
// PORT
// =====================================================

const PORT =
    process.env.PORT || 5000


app.listen(
    PORT,
    () => {

        console.log(
            `Server is running on port ${PORT}!`
        )
    }
)